# WebShell
Web Shell Detector is a PHP script designed to identify PHP, CGI (Perl), ASP/ASPX shells. It uses a "web shells" signature database to detect shells with up to 99% accuracy. The tool features a lightweight and user-friendly interface built with modern JavaScript and CSS technologies.
